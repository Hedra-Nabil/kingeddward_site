<!DOCTYPE html>
<html lang="en">

<?php $title='Trekee-Tours & Travel Agency PHP Template'?>
<?php include './parts/head.php'?> 

<!-- page wrapper -->
<body>
    <div class="boxed_wrapper">
        
    <!-- Preloader -->
   <?php include './parts/preloader.php'?>   
        
            <?php $header_class='main-header style-one common-header'; $nav_active=''; include './parts/header.php'?>

        
   <!-- Search Form -->
   <?php include './parts/search.php'?>  

    <!-- mobile-menu Area-->
   <?php include './parts/mobile-menu.php'?>  
        
    <!-- Breadcrumb Section -->
   <?php 
      $mainHeading='It appears that this site is missing.';
      $subHeading='404';
   ?>
   <?php include './parts/breadcrumb.php'?>   

        <!-- error -->
        <div class="error">
            <div class="container">
                <div class="row">
                    <div class="col-lg-8 offset-lg-2">
                        <div class="error-container">
                            <div class="error-image">
                                <img src="assets/images/gallery/error.png" alt="error">
                            </div>
                            <p>The page you are looking for might have been removed had its name changed or is <br> temporarily unavailable.</p>
                            <div class="btn-group">
                                <div class="header-link-btn"><a class='btn-1' href='index.php'> Back To Home<span></span></a></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- error -->

            <?php include './parts/footer.php'?>   
        
    </div>


    <!-- All JavaScript Files-->
   <?php include './parts/script.php'?>  

</body><!-- End of .page_wrapper -->

</html>
