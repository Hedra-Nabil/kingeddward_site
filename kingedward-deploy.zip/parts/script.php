<!-- All JavaScript Files-->
<script src="assets/js/jquery.js"></script>
<script src="assets/js/popper.min.js"></script>
<script src="assets/js/bootstrap.min.js"></script>
<script src="assets/js/fontawesome.min.js"></script>
<script src="assets/js/all.min.js"></script>
<script src="assets/js/owl.js"></script>
<script src="assets/js/wow.js"></script>
<script src="assets/js/slick.min.js"></script>
<script src="assets/js/validation.js"></script>
<script src="assets/js/progresscircle.js"></script>
<script src="assets/js/scrollbar.js"></script>
<script src="assets/js/appear.js"></script>
<script src="assets/js/jquery.nice-select.min.js"></script>
<script src="assets/js/swiper.min.js"></script>
<script src="assets/js/parallax.min.js"></script>
<script src="assets/js/jquery.fancybox.js"></script>
<script src="assets/js/jquery.magnific-popup.js"></script>
<script src="assets/js/parallax-scroll.js"></script>
<script src="assets/js/jquery.paroller.min.js"></script>

<!-- main-js -->
<script src="assets/js/script.js"></script>

<?php echo (isset($script) ? $script   : '')?>

